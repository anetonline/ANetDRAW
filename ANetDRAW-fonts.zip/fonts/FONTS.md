# ANetDRAW font pack: TheDraw fonts

This pack holds 3716 TheDraw (`.TDF`) banner fonts in 1187 files.
Unzip it into the ANetDRAW folder so the fonts land in `fonts/`, or point
the door at them with `--fonts DIR`. In the editor, **^T** then **T**
types text in any of them. `FONTLIST.txt` lists every font by file and
name.

## Where these fonts come from

TheDraw fonts were made by BBS-era ANSI artists in the late 1980s and
1990s and passed around freely on bulletin boards for decades. This pack
was built from the collection compiled and preserved by
**Roy/SAC** (Roy of Superior Art Creations,
<https://www.roysac.com/thedrawfonts-tdf.html>). The same fonts ship
with other BBS software, such as Synchronet (`ctrl/tdfonts`) and
tdfiglet.

The `.TDF` font format and the TheDraw editor are by **Ian E. Davis**
(TheSoft Programming Services).

## Credits found in the fonts

A TheDraw font file has no author field, so most fonts don't name their
creator. These credits appear inside the font data itself:

- by Kirth Gersen of SpaceLink BBS (Future, MiddleAge, Tech)

If you drew one of these fonts, we'd be glad to add your name here.

## Status and removal

These fonts come with **no license**. As far as anyone knows, their
authors released them as freeware for BBS use, and they have circulated
openly ever since. Only one font in the source collection carries an
explicit rights reservation, and it has been **left out** of this pack:

- `tdf-fonts/3D-FADE.TDF` font "3D-Fade": the font data says "All-Rights Reserved"
- `tdf-fonts/SETS/TDFONTS2.TDF` font "3D-Fade": the font data says "All-Rights Reserved"

**If you are the author of a font in this pack and want it credited
differently or removed, contact the ANetDRAW author and it will be done
in the next release.**

The pack was built by `util/make_fontpack.py`. It read 5098 fonts,
kept one copy of each distinct font, and dropped the excluded ones.
